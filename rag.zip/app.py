import os
import uuid
import logging
import re
from flask import Flask, request, redirect, url_for, render_template, flash, jsonify
from werkzeug.utils import secure_filename
from qdrant_client import QdrantClient
from qdrant_client.http import models as qmodels
from transformers import AutoTokenizer, AutoModel
import torch
from docx import Document
import markdown
import openai
from dotenv import load_dotenv
import pdfplumber
import io

# 載入環境變數
load_dotenv()

# OpenAI API 設定
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
OPENAI_MODEL = "gpt-3.5-turbo"

# ---------------------------
# 初始化 Flask 與相關設定
# ---------------------------
app = Flask(__name__, 
           template_folder='templates',  # Explicitly set template folder
           static_folder='static')
app.config['SECRET_KEY'] = 'your_secret_key_here'
app.config['UPLOAD_FOLDER'] = 'uploads'
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# ---------------------------
# 配置日誌
# ---------------------------
logging.basicConfig(level=logging.INFO)
logging.getLogger('pdfminer').setLevel(logging.ERROR)
logging.getLogger('PIL').setLevel(logging.WARNING)
logging.getLogger('werkzeug').setLevel(logging.WARNING)
logging.getLogger('httpx').setLevel(logging.WARNING)
logging.getLogger('qdrant_client').setLevel(logging.WARNING)

# ---------------------------
# 初始化 Qdrant 向量資料庫客戶端
# ---------------------------
qdrant_client = QdrantClient("localhost", port=6333)

# ---------------------------
# 初始化 Transformer 模型與分詞器
# ---------------------------
tokenizer = AutoTokenizer.from_pretrained("sentence-transformers/all-mpnet-base-v2")
model = AutoModel.from_pretrained("sentence-transformers/all-mpnet-base-v2")

# ---------------------------
# 初始化 OpenAI 客戶端
# ---------------------------
openai_client = openai.OpenAI(api_key=OPENAI_API_KEY)

def ensure_collection_exists(name):
    """確保 Qdrant collection 存在"""
    existing = [c.name for c in qdrant_client.get_collections().collections]
    if name not in existing:
        qdrant_client.create_collection(
            collection_name=name,
            vectors_config=qmodels.VectorParams(size=768, distance=qmodels.Distance.COSINE)
        )
        logging.info(f"🆕 Collection '{name}' created.")
    else:
        logging.info(f"✅ Collection '{name}' exists.")

def encode_text(text):
    """使用 all-mpnet-base-v2 將文字轉換為 768 維向量"""
    try:
        inputs = tokenizer(text, padding=True, truncation=True, return_tensors="pt", max_length=512)
        with torch.no_grad():
            outputs = model(**inputs)
        embeddings = outputs.last_hidden_state.mean(dim=1)
        return embeddings[0].tolist()
    except Exception as e:
        logging.error(f"向量編碼錯誤: {e}")
        return [0.0] * model.config.hidden_size

def split_into_chunks(text, chunk_size=500, overlap=50):
    """將文字切分成較小的 chunks"""
    chunks = []
    start = 0
    length = len(text)
    while start < length:
        end = min(start + chunk_size, length)
        snippet = text[start:end].strip()
        if snippet:
            chunks.append(snippet)
        start += (chunk_size - overlap)
    return chunks

def clean_text(text):
    """清理文字"""
    text = re.sub(r"[\x00-\x1F\x7F]", "", text)
    text = re.sub(r"[^\u4e00-\u9fff\w\d\s.,!?:：；()（）\-–—]", "", text)
    text = re.sub(r"\s{2,}", " ", text)
    return text.strip()

def extract_text_from_pdf(pdf_path):
    """從 PDF 文件中擷取文字"""
    try:
        text_content = ""
        with pdfplumber.open(pdf_path) as pdf:
            for page in pdf.pages:
                page_text = page.extract_text() or ""
                if page_text.strip():
                    text_content += f"\n{page_text}"
        return text_content.strip()
    except Exception as e:
        logging.error(f"PDF 擷取失敗: {e}")
        return ""

def extract_text_from_docx(docx_path):
    """從 DOCX 文件中擷取文字"""
    try:
        doc = Document(docx_path)
        text_lines = []
        for para in doc.paragraphs:
            text_lines.append(para.text)
        return " ".join(text_lines)
    except Exception as e:
        logging.error(f"DOCX 文字提取錯誤: {e}")
        return ""

def generate_answer(content, query):
    """使用 OpenAI 生成回答"""
    try:
        response = openai_client.chat.completions.create(
            model=OPENAI_MODEL,
            messages=[
                {"role": "system", "content": "你是一個專業的助手，請根據提供的內容用繁體中文回答問題。使用 markdown 格式，但不要包含程式碼。"},
                {"role": "user", "content": f"請根據以下內容回答問題：\n\n內容：{content}\n\n問題：{query}"}
            ],
            temperature=0.7,
            max_tokens=1000
        )
        answer = response.choices[0].message.content.strip()
        return markdown.markdown(answer)
    except Exception as e:
        logging.error(f"OpenAI API 錯誤: {e}")
        return f"錯誤：{e}"

def get_collection_file_count(collection_name):
    """獲取 collection 中的檔案數量"""
    try:
        points, _ = qdrant_client.scroll(collection_name=collection_name, limit=9999)
        unique_files = {pt.payload.get("filename") for pt in points if pt.payload and "filename" in pt.payload}
        return len(unique_files)
    except Exception as e:
        logging.error(f"獲取檔案數量時發生錯誤: {e}")
        return 0

@app.route('/')
def index():
    """首頁，顯示所有 Collection"""
    collections = qdrant_client.get_collections().collections
    return render_template('index.html', collections=collections)

@app.route('/create_collection', methods=['POST'])
def create_collection():
    """建立新的 Qdrant Collection"""
    collection_name = request.form['collection_name']
    ensure_collection_exists(collection_name)
    flash('Collection created successfully!')
    return redirect(url_for('index'))

@app.route('/delete_collection/<collection_name>', methods=['POST'])
def delete_collection(collection_name):
    """刪除指定 Collection"""
    try:
        qdrant_client.delete_collection(collection_name=collection_name)
        flash(f"Collection '{collection_name}' deleted.")
    except Exception as e:
        logging.error(f"刪除集合失敗: {e}")
        flash(f"删除集合時出錯: {str(e)}")
    return redirect(url_for('index'))

@app.route('/upload_to_collection/<path:collection_name>', methods=['GET', 'POST'])
def upload_to_collection(collection_name):
    """上傳文件至指定的 Qdrant 集合"""
    if request.method == 'POST':
        if 'file' not in request.files:
            return jsonify({"status": "error", "message": "No file part"}), 400
            
        file = request.files['file']
        if not file or file.filename == '':
            return jsonify({"status": "error", "message": "No selected file"}), 400

        # 檢查檔案大小（30MB = 30 * 1024 * 1024 bytes）
        MAX_FILE_SIZE = 30 * 1024 * 1024
        file.seek(0, os.SEEK_END)
        file_size = file.tell()
        file.seek(0)
        
        if file_size > MAX_FILE_SIZE:
            return jsonify({
                "status": "error",
                "message": f"檔案大小超過限制（30MB）。當前檔案大小：{file_size / (1024 * 1024):.1f}MB"
            }), 400

        # 檢查檔案類型
        file_extension = os.path.splitext(file.filename)[1].lower()
        if file_extension not in ['.pdf', '.docx']:
            return jsonify({"status": "error", "message": "Only PDF and DOCX files are allowed"}), 400

        try:
            # 檢查檔案數量限制
            current_file_count = get_collection_file_count(collection_name)
            if current_file_count >= 10:
                return jsonify({
                    "status": "error",
                    "message": "已達到檔案數量上限（10個檔案）。請先刪除一些檔案後再上傳。"
                }), 400

            filename = secure_filename(file.filename)
            
            # 直接在記憶體中處理檔案
            if file_extension == '.pdf':
                # 使用 BytesIO 在記憶體中處理 PDF
                pdf_bytes = file.read()
                with pdfplumber.open(io.BytesIO(pdf_bytes)) as pdf:
                    full_text = ""
                    for page in pdf.pages:
                        page_text = page.extract_text() or ""
                        if page_text.strip():
                            full_text += f"\n{page_text}"
            else:  # .docx
                # 使用 BytesIO 在記憶體中處理 DOCX
                docx_bytes = file.read()
                doc = Document(io.BytesIO(docx_bytes))
                text_lines = []
                for para in doc.paragraphs:
                    text_lines.append(para.text)
                full_text = " ".join(text_lines)

            if not full_text.strip():
                raise Exception("無法提取文字內容")

            # 清理文字
            full_text = clean_text(full_text)

            # 切分並儲存到 Qdrant
            ensure_collection_exists(collection_name)
            chunk_list = split_into_chunks(full_text, chunk_size=500, overlap=50)

            for chunk_text in chunk_list:
                vec = encode_text(chunk_text)
                point_id = str(uuid.uuid4())
                qdrant_client.upsert(
                    collection_name=collection_name,
                    points=[qmodels.PointStruct(id=point_id, vector=vec, payload={"filename": filename, "content": chunk_text})]
                )

            return jsonify({
                "status": "success",
                "message": "File processed successfully",
                "filename": filename
            })

        except Exception as e:
            logging.error(f"處理檔案時發生錯誤: {e}")
            return jsonify({"status": "error", "message": str(e)}), 500

    # 獲取當前檔案數量並傳遞給模板
    current_file_count = get_collection_file_count(collection_name)
    return render_template('upload.html', 
                         collection_name=collection_name,
                         current_file_count=current_file_count)

@app.route('/ask/<path:collection_name>', methods=['GET', 'POST'])
def ask(collection_name):
    """問答功能"""
    if request.method == 'POST':
        query = request.form['query']
        try:
            # 將查詢轉換為向量
            query_vector = encode_text(query)

            # 查詢 Qdrant
            search_results = qdrant_client.search(
                collection_name=collection_name,
                query_vector=query_vector,
                limit=5
            )

            # 收集相關文本
            context_texts = [res.payload.get("content", "") for res in search_results if res.payload]
            context = "\n\n".join(context_texts)

            # 生成回答
            answer = generate_answer(context, query)

            return render_template("ask.html",
                               collection_name=collection_name,
                               query=query,
                               answer=answer,
                               context_texts=context_texts)

        except Exception as e:
            logging.error(f"查詢處理錯誤: {e}")
            flash(f"搜索錯誤: {str(e)}")
            return redirect(request.url)

    return render_template("ask.html", collection_name=collection_name)

@app.route('/file_list/<path:collection_name>')
def file_list(collection_name):
    """顯示檔案列表"""
    try:
        points, _ = qdrant_client.scroll(collection_name=collection_name, limit=9999)
        filenames = sorted({pt.payload.get("filename") for pt in points if pt.payload and "filename" in pt.payload})
        
        # 分頁設定
        page = request.args.get('page', 1, type=int)
        per_page = 10
        total_files = len(filenames)
        total_pages = (total_files + per_page - 1) // per_page
        page = max(1, min(page, total_pages))

        # 計算當前頁的檔案
        start_idx = (page - 1) * per_page
        end_idx = start_idx + per_page
        current_page_filenames = filenames[start_idx:end_idx]

        return render_template('file_list.html',
                             collection_name=collection_name,
                             filenames=current_page_filenames,
                             total_files=total_files,
                             current_page=page,
                             total_pages=total_pages)

    except Exception as e:
        logging.error(f"Error displaying file list: {e}")
        flash(f"顯示檔案列表時出錯: {str(e)}", "error")
        return redirect(url_for('index'))

@app.route('/delete_file/<path:collection_name>/<path:filename>', methods=['POST'])
def delete_file(collection_name, filename):
    """刪除檔案及其相關資料"""
    try:
        # 從 Qdrant 刪除
        points, _ = qdrant_client.scroll(
            collection_name=collection_name,
            limit=9999
        )
        
        for point in points:
            if point.payload and point.payload.get("filename") == filename:
                qdrant_client.delete(
                    collection_name=collection_name,
                    points_selector=qmodels.PointIdsList(
                        points=[point.id]
                    )
                )

        return jsonify({
            "status": "success",
            "message": f"File '{filename}' and all associated data deleted successfully"
        })

    except Exception as e:
        logging.error(f"Error deleting file {filename}: {e}")
        return jsonify({
            "status": "error",
            "message": f"Failed to delete file: {str(e)}"
        }), 500

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5001, debug=True)

